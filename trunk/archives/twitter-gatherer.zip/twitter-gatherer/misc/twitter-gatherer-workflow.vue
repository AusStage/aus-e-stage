<!-- Tufts VUE 3.0.2 concept-map (twitter-gatherer-workflow.vue) 2010-09-09 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/opt/vue/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Thu Sep 09 13:15:18 CST 2010 by techxplorer on platform Linux 2.6.32-24-generic in JVM 1.6.0_20-b02 -->
<!-- Do Not Remove: Saving version @(#)VUE: built July 1 2010 at 1436 by vue on Linux 2.4.21-57.EL i386 JVM 1.5.0_06-b05(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0"
    label="twitter-gatherer-workflow.vue" created="1284002229048"
    x="0.0" y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1284003918269"
        spec="/home/techxplorer/aus-e-stage/twitter-gatherer/misc/twitter-gatherer-workflow.vue"
        type="1" xsi:type="URLResource">
        <title>twitter-gatherer-workflow.vue</title>
        <property key="File" value="/home/techxplorer/aus-e-stage/twitter-gatherer/misc/twitter-gatherer-workflow.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <metadata-list category-list-size="1" other-list-size="0"
        ontology-list-size="0" RCategoryListSize="0">
        <ontology-list-string></ontology-list-string>
        <metadata xsi:type="vue-metadata-element">
            <value></value>
            <key>http://vue.tufts.edu/vue.rdfs#none</key>
            <type>1</type>
        </metadata>
    </metadata-list>
    <URIString>http://vue.tufts.edu/rdf/resource/f498f1cf7f00010104a40050ffe73acd</URIString>
    <child ID="6" label="A Tweet is entered into Twitter by a user"
        layerID="1" created="1284002247269" x="547.5" y="87.0"
        width="265.0" height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#D4E6C1</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1d07f00010104a40050a80b1548</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="7" label="Twitter Gatherer Workflow" layerID="1"
        created="1284002355544" x="334.0" y="29.0" width="686.0"
        height="21.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <fillColor>#FFFFFF</fillColor>
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1e17f00010104a4005094d2dbb1</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-size: 12; margin-bottom: 0px; margin-right: 0px; margin-top: 0px; margin-left: 0px; color: #000000; font-family: Arial }
        ol { font-size: 12; vertical-align: middle; margin-top: 6; margin-left: 30; list-style-position: outside; font-family: Arial }
        p { margin-bottom: 0; margin-right: 0; margin-top: 0; margin-left: 0; color: #000000 }
        ul { font-size: 12; vertical-align: middle; margin-top: 6; margin-left: 30; font-family: Arial; list-style-position: outside }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="text-align: center; color: #000000" color="#000000"&gt;
      &lt;font style="font-size:14;"&gt;&lt;b&gt;Twitter Gatherer Workflow&lt;/b&gt;&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Twitter Gatherer Workflow</label>
    </child>
    <child ID="9"
        label="The Tweet is received by the Twitter Gatherer&#xa;application via the Twitter Streaming API &amp;&#xa;the tweetStream4J library"
        layerID="1" created="1284002434436" x="532.5" y="150.00206"
        width="295.0" height="53.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#C1D4E6</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1e57f00010104a400501eada843</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="10"
        label="Personally identifying information is removed from the Tweet"
        layerID="1" created="1284002576493" x="486.0" y="243.00412"
        width="388.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#C1D4E6</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1e77f00010104a4005051f4df31</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="11"
        label="A copy of the Tweet is stored in a file on the server"
        layerID="1" created="1284002629987" x="515.0" y="301.0"
        width="330.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#C1D4E6</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1e97f00010104a40050a27d5d5c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="13"
        label="The hash tags contained in the Tweet are extracted"
        layerID="1" created="1284002670556" x="511.0" y="369.0082"
        width="338.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#C1D4E6</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1ea7f00010104a4005074fb9844</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="14"
        label="Possible performances are identified by looking in the AusStage database&#xa;for performances underway at the time the Tweet was sent"
        layerID="1" created="1284002712196" x="442.0" y="432.01025"
        width="476.0" height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#C1D4E6</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1ec7f00010104a4005077b85c9a</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="15"
        label="The list of hash tags associated with performances ist matched against&#xa;the list of hash tags extract from the tweet"
        layerID="1" created="1284002761954" x="449.5" y="510.01233"
        width="461.0" height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#C1D4E6</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1ed7f00010104a40050fe438f91</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="16" label="If a match is found" layerID="1"
        created="1284002829518" x="442.5" y="619.9166" width="127.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#D3C1E6</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1ee7f00010104a40050f6cbb2fb</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="17" label="If a match is not found" layerID="1"
        created="1284002843404" x="765.5" y="619.9166" width="152.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#E6C1C2</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1f07f00010104a400502ab05476</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="18"
        label="A copy of the Tweet is stored in the database&#xa;along with some additional metadata"
        layerID="1" created="1284002863268" x="357.5" y="692.58325"
        width="297.0" height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#D3C1E6</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1f17f00010104a40050c45eb410</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="19"
        label="An exception report is generated and sent via&#xa;email to AusStage staff for analysis"
        layerID="1" created="1284002892349" x="691.5" y="692.58325"
        width="300.0" height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#E6C1C2</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1f27f00010104a400501f5ceb8d</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="20" layerID="1" created="1284003013053" x="679.5"
        y="109.50001" width="1.0" height="41.00206" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1f37f00010104a4005083f593ac</URIString>
        <point1 x="680.0" y="110.0"/>
        <point2 x="680.0" y="150.00206"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">9</ID2>
    </child>
    <child ID="21" layerID="1" created="1284003016064" x="679.5"
        y="202.50204" width="1.0" height="41.00206" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1f57f00010104a4005016604a0a</URIString>
        <point1 x="680.0" y="203.00206"/>
        <point2 x="680.0" y="243.00412"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">10</ID2>
    </child>
    <child ID="22" layerID="1" created="1284003018776" x="679.5"
        y="265.50415" width="1.0" height="35.99588" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1fc7f00010104a400502b0446b8</URIString>
        <point1 x="680.0" y="266.00412"/>
        <point2 x="680.0" y="301.0"/>
        <ID1 xsi:type="node">10</ID1>
        <ID2 xsi:type="node">11</ID2>
    </child>
    <child ID="23" layerID="1" created="1284003020826" x="679.5"
        y="323.5" width="1.0" height="46.00821" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f1ff7f00010104a400503f6d6f2a</URIString>
        <point1 x="680.0" y="324.0"/>
        <point2 x="680.0" y="369.0082"/>
        <ID1 xsi:type="node">11</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <child ID="24" layerID="1" created="1284003022876" x="679.5"
        y="391.50818" width="1.0" height="41.002045" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f2017f00010104a40050c3e545b2</URIString>
        <point1 x="680.0" y="392.0082"/>
        <point2 x="680.0" y="432.01025"/>
        <ID1 xsi:type="node">13</ID1>
        <ID2 xsi:type="node">14</ID2>
    </child>
    <child ID="25" layerID="1" created="1284003024507" x="679.5"
        y="469.51025" width="1.0" height="41.002075" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f2037f00010104a4005054654339</URIString>
        <point1 x="680.0" y="470.01025"/>
        <point2 x="680.0" y="510.01233"/>
        <ID1 xsi:type="node">14</ID1>
        <ID2 xsi:type="node">15</ID2>
    </child>
    <child ID="26" layerID="1" created="1284003027332" x="525.04016"
        y="547.5123" width="123.176025" height="72.9043"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f2047f00010104a40050d8b28eb4</URIString>
        <point1 x="647.7162" y="548.0123"/>
        <point2 x="525.54016" y="619.9166"/>
        <ID1 xsi:type="node">15</ID1>
        <ID2 xsi:type="node">16</ID2>
    </child>
    <child ID="27" layerID="1" created="1284003029569" x="505.5"
        y="642.4166" width="1.0" height="50.666626" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f2057f00010104a400509f26e5e8</URIString>
        <point1 x="506.0" y="642.9166"/>
        <point2 x="506.0" y="692.58325"/>
        <ID1 xsi:type="node">16</ID1>
        <ID2 xsi:type="node">18</ID2>
    </child>
    <child ID="28" layerID="1" created="1284003031555" x="709.46454"
        y="547.5123" width="114.39905" height="72.9043"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f2077f00010104a40050483cea76</URIString>
        <point1 x="709.96454" y="548.0123"/>
        <point2 x="823.3636" y="619.9166"/>
        <ID1 xsi:type="node">15</ID1>
        <ID2 xsi:type="node">17</ID2>
    </child>
    <child ID="29" layerID="1" created="1284003033551" x="841.0"
        y="642.4166" width="1.0" height="50.666626" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f2087f00010104a40050ccc731b9</URIString>
        <point1 x="841.5" y="642.9166"/>
        <point2 x="841.5" y="692.58325"/>
        <ID1 xsi:type="node">17</ID1>
        <ID2 xsi:type="node">19</ID2>
    </child>
    <child ID="30" label="AusStage Database" layerID="1"
        created="1284003330164" x="438.0" y="778.0" width="136.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#E6E6C1</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f2097f00010104a40050e2b7f4ef</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="31" label="Directory of log files&#xa;on the server"
        layerID="1" created="1284003349112" x="939.0" y="293.5"
        width="135.0" height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#E6E6C1</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f20d7f00010104a40050ccaabf81</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="32" layerID="1" created="1284003418234" x="844.5"
        y="312.0" width="95.0" height="1.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f20e7f00010104a40050241f135a</URIString>
        <point1 x="845.0" y="312.5"/>
        <point2 x="939.0" y="312.5"/>
        <ID1 xsi:type="node">11</ID1>
        <ID2 xsi:type="node">31</ID2>
    </child>
    <child ID="33" layerID="1" created="1284003421564" x="505.5"
        y="730.08325" width="1.0" height="48.416748" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f20f7f00010104a400506721c108</URIString>
        <point1 x="506.0" y="730.58325"/>
        <point2 x="506.0" y="778.0"/>
        <ID1 xsi:type="node">18</ID1>
        <ID2 xsi:type="node">30</ID2>
    </child>
    <child ID="34" label="Legend" layerID="1" created="1284003453380"
        x="1005.0" y="502.0" width="233.25" height="160.75"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FFFFFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f2117f00010104a400504090518f</URIString>
        <child ID="35" label="Twitter System" created="1284003477882"
            x="34.0" y="25.0" width="258.0" height="23.0"
            strokeWidth="1.0" autoSized="false" xsi:type="node">
            <fillColor>#D4E6C1</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f498f2127f00010104a400506eaa1ce9</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="36" label="Twitter Gatherer Processes"
            created="1284003489835" x="34.0" y="45.25" width="258.0"
            height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
            <fillColor>#C1D4E6</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f498f2157f00010104a40050a0f01ba3</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="37" label="A matching performance is found"
            created="1284003512825" x="34.0" y="65.5" width="258.0"
            height="23.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
            <fillColor>#D3C1E6</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f498f2177f00010104a400506dfe885d</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="38" label="A matching performance was not found"
            created="1284003529250" x="34.0" y="85.75" width="258.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#E6C1C2</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f498f2187f00010104a4005065a9c683</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="39" label="External Storage" created="1284003540874"
            x="34.0" y="106.0" width="258.0" height="23.0"
            strokeWidth="1.0" autoSized="false" xsi:type="node">
            <fillColor>#E6E6C1</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f498f21a7f00010104a40050e7be3d05</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="40"
            label="Version: 1.0.0&#xa;Last Updated: 09/09/2010"
            created="1284003582153" x="34.0" y="126.25" width="258.0"
            height="38.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
            <fillColor>#FFFFFF</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f498f21c7f00010104a4005024ccd7ef</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <layer ID="1" label="Layer 1" created="1284002229052" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <metadata-list category-list-size="0" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f498f21e7f00010104a400501140db5a</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-120.75" y="-12.0"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" created="1284002229046"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="-1" open="true">
            <strokeColor>#B3993333</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="0" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f498f21f7f00010104a40050a9f98627</URIString>
            <masterSlide ID="2" created="1284002229074" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <metadata-list category-list-size="0"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/f498f2207f00010104a400505220adaf</URIString>
                <titleStyle ID="3" label="Header"
                    created="1284002231019" x="329.0" y="174.5"
                    width="142.0" height="51.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/f498f2217f00010104a40050d1fc8ce6</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1284002231039" x="340.0" y="282.5"
                    width="120.0" height="35.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/f498f2237f00010104a40050465d50a5</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1284002231040"
                    x="372.5" y="385.0" width="55.0" height="30.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/f498f2247f00010104a400505287bbc5</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2010-09-09</date>
    <mapFilterModel/>
    <modelVersion>5</modelVersion>
    <saveLocation>/home/techxplorer/aus-e-stage/twitter-gatherer/misc</saveLocation>
    <saveFile>/home/techxplorer/aus-e-stage/twitter-gatherer/misc/twitter-gatherer-workflow.vue</saveFile>
</LW-MAP>
