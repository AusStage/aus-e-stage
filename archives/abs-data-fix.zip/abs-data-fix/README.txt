More information about this application, including usage instructions, is 
available on the aus-e-stage Google Code Wiki available here:

http://code.google.com/p/aus-e-stage/wiki/AbsDataFix
