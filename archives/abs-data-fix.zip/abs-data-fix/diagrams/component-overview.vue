<!-- Tufts VUE 3.0 concept-map (component-overview.vue) 2010-05-28 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/opt/vue/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Fri May 28 14:37:09 CST 2010 by techxplorer on platform Linux 2.6.32-22-generic in JVM 1.6.0_20-b02 -->
<!-- Do Not Remove: Saving version @(#)VUE: built February 3 2010 at 1428 by vue on Linux 2.4.21-57.EL i386 JVM 1.5.0_06-b05(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0"
    label="component-overview.vue" created="1263340196976" x="0.0"
    y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1275023229865" size="52912"
        spec="/home/techxplorer/aus-e-stage/abs-data-fix/diagrams/component-overview.vue"
        type="1" xsi:type="URLResource">
        <title>component-overview.vue</title>
        <property key="File" value="/home/techxplorer/aus-e-stage/abs-data-fix/diagrams/component-overview.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <metadata-list category-list-size="1" other-list-size="0"
        ontology-list-size="0" RCategoryListSize="0">
        <ontology-list-string></ontology-list-string>
        <metadata xsi:type="vue-metadata-element">
            <value></value>
            <key>http://vue.tufts.edu/vue.rdfs#none</key>
            <type>1</type>
        </metadata>
    </metadata-list>
    <URIString>http://vue.tufts.edu/rdf/resource/250dea8b7f00010100262adcea666f5e</URIString>
    <child ID="79" label="Legend" layerID="1" created="1263344033976"
        x="-36.02539" y="194.3227" width="157.75952" height="113.5"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FFFFFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/253233d17f00010100262adca94d91a0</URIString>
        <child ID="271" label="Main Driving Class"
            created="1275020635761" x="34.0" y="25.0" width="149.0127"
            height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
            <fillColor>#77CACA</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fbe7f00010101f45f2a0595cbdf</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="75" label="Java Class" created="1263343722953"
            x="34.0" y="46.75" width="149.0127" height="25.0"
            strokeWidth="1.0" autoSized="false" xsi:type="node">
            <fillColor>#77A1CA</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/252c0d527f00010100262adcd46d8f12</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="76" label="Java Abstract Class"
            created="1263343733121" x="34.0" y="68.5" width="149.0127"
            height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
            <fillColor>#A177CA</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/252c0d537f00010100262adcc64b255b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="305" label="Third Party Code" created="1275022982037"
            x="34.0" y="90.25" width="149.0127" height="23.0"
            strokeWidth="1.0" autoSized="false" xsi:type="node">
            <fillColor>#CA7777</fillColor>
            <strokeColor>#000000</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/dd4bd0f27f00010101f45f2a139d2da6</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="27"
        label="ABS Data Fix Application &#xa;    &#xa;    &#xa;      Component Overview Diagram"
        layerID="1" created="1263341122733" x="-793.34143" y="-259.3105"
        width="329.0" height="65.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-bold-18</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/250deaca7f00010100262adc43520afb</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { margin-left: 0px; margin-right: 0px; margin-bottom: 0px; margin-top: 0px; color: #000000; font-size: 12; font-family: Arial }
        ol { margin-left: 30; vertical-align: middle; margin-top: 6; list-style-position: outside; font-size: 12; font-family: Arial }
        p { margin-left: 0; margin-right: 0; margin-bottom: 0; margin-top: 0; color: #000000 }
        ul { margin-left: 30; vertical-align: middle; margin-top: 6; list-style-position: outside; font-family: Arial; font-size: 12 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="text-align: center; color: #000000" color="#000000"&gt;
      
    &lt;/p&gt;
    &lt;p style="text-align: center; color: #000000" color="#000000"&gt;
      &lt;font style="font-size:18;"&gt;ABS Data Fix Application 
&lt;/font&gt;    &lt;/p&gt;
    &lt;p style="text-align: center; color: #000000" color="#000000"&gt;
      &lt;font style="font-size:18;"&gt;Component Overview Diagram&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>ABS Data Fix Application 
    
    
      Component Overview Diagram</label>
    </child>
    <child ID="91" label="Last Updated: 28 May 2010&#xa;Version: 1.0.0"
        layerID="1" created="1263364823060" x="-86.13791" y="337.13226"
        width="188.26819" height="42.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#FFFFFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/266b2fed7f0001010080d0288267939c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="235" label="Notes" layerID="1" created="1272336056717"
        x="-496.02606" y="384.63367" width="603.0" height="107.0"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FFFFFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/3d284adc7f00010101b0e2c3c92c2c7b</URIString>
        <child ID="236"
            label="Arrows between the main driving class and java classes show data flows&#xa;      &#xa;      &#xa;        Arrows between abstract classes and classes show inheritance&#xa;      &#xa;      &#xa;        Arrows between classes show use&#xa;      &#xa;      &#xa;        Class names with a * indicate classes yet to be developed"
            created="1272336064640" x="5.0" y="25.0" width="593.0"
            height="76.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/3d284adc7f00010101b0e2c3e17fa829</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { margin-left: 0px; margin-right: 0px; margin-bottom: 0px; margin-top: 0px; color: #000000; font-size: 12; font-family: Arial }
        ol { margin-left: 30; vertical-align: middle; margin-top: 6; list-style-position: outside; font-size: 12; font-family: Arial }
        p { margin-left: 0; margin-right: 0; margin-bottom: 0; margin-top: 0; color: #000000 }
        ul { margin-left: 30; vertical-align: middle; margin-top: 6; list-style-position: outside; font-family: Arial; font-size: 12 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;ul color="#000000"&gt;
      &lt;li style="color: #000000" color="#000000"&gt;
        Arrows between the main driving class and java classes show data flows
      &lt;/li&gt;
      &lt;li style="color: #000000" color="#000000"&gt;
        Arrows between abstract classes and classes show inheritance
      &lt;/li&gt;
      &lt;li style="color: #000000" color="#000000"&gt;
        Arrows between classes show use
      &lt;/li&gt;
      &lt;li style="color: #000000" color="#000000"&gt;
        Class names with a * indicate classes yet to be developed
      &lt;/li&gt;
    &lt;/ul&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Arrows between the main driving class and java classes show data flows
      
      
        Arrows between abstract classes and classes show inheritance
      
      
        Arrows between classes show use
      
      
        Class names with a * indicate classes yet to be developed</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="272" label="PrepareKML" layerID="1"
        created="1275020679256" x="-645.26587" y="119.189514"
        width="126.0" height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#77A1CA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fc77f00010101f45f2a20179ea7</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="273" label="Tasks" layerID="1" created="1275020679256"
        x="-290.64563" y="-170.7439" width="130.0" height="25.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#A177CA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fc77f00010101f45f2a2ccfdffd</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="275" label="AbsDataFix" layerID="1"
        created="1275020679256" x="-1092.7659" y="-76.877075"
        width="126.0" height="245.23322" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#77CACA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fc87f00010101f45f2a7e7e0726</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="277" label="Command Line &#xa;Argument Values"
        layerID="1" created="1275020729908" x="-1078.7659" y="167.85614"
        width="98.0" height="103.5" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fc97f00010101f45f2ab023c69e</URIString>
        <point1 x="-1029.7659" y="168.35614"/>
        <point2 x="-1029.7659" y="270.85614"/>
        <ID1 xsi:type="node">275</ID1>
        <ID2 xsi:type="node">307</ID2>
    </child>
    <child ID="278" label="AbsAgeBySex" layerID="1"
        created="1275020792527" x="-645.26587" y="-98.810486"
        width="126.0" height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#77A1CA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fca7f00010101f45f2a001bfd9a</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="279" label="AddMetadata" layerID="1"
        created="1275020818709" x="-645.26587" y="228.18951"
        width="126.0" height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#77A1CA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fca7f00010101f45f2ac467985e</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="280" label="AppendCDInfo" layerID="1"
        created="1275020833004" x="-645.26587" y="10.189514"
        width="126.0" height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#77A1CA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fcb7f00010101f45f2a9da4b7b7</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="281" label="DataBuilder" layerID="1"
        created="1275020844596" x="-645.26587" y="-44.310486"
        width="126.0" height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#77A1CA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fcc7f00010101f45f2af249ae7c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="282" label="KmlNamespaceContext" layerID="1"
        created="1275020867091" x="-273.76587" y="225.68951"
        width="154.0" height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#77A1CA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fcc7f00010101f45f2ae0eac09b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="283" label="MapAgeBySex" layerID="1"
        created="1275020886969" x="-645.26587" y="173.68951"
        width="126.0" height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#77A1CA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fcd7f00010101f45f2a1d6f4a0b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="284" label="DataAppender*" layerID="1"
        created="1275020910944" x="-645.26587" y="64.689514"
        width="126.0" height="25.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#77A1CA</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fce7f00010101f45f2aa6911e11</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="285" layerID="1" created="1275021035920" x="-520.49927"
        y="-146.2439" width="286.0409" height="67.38678"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fce7f00010101f45f2a7d2e7480</URIString>
        <point1 x="-519.99927" y="-92.4436"/>
        <point2 x="-234.95837" y="-145.7439"/>
        <ID1 xsi:type="node">278</ID1>
        <ID2 xsi:type="node">273</ID2>
        <ctrlPoint0 x="-447.2001" y="-99.61417" xsi:type="point"/>
        <ctrlPoint1 x="-319.24622" y="-32.608974" xsi:type="point"/>
    </child>
    <child ID="286" layerID="1" created="1275021057238" x="-519.76587"
        y="-146.2439" width="285.85303" height="128.67494"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fcf7f00010101f45f2a3686f1ce</URIString>
        <point1 x="-519.26587" y="-32.51927"/>
        <point2 x="-234.41283" y="-145.7439"/>
        <ID1 xsi:type="node">281</ID1>
        <ID2 xsi:type="node">273</ID2>
        <ctrlPoint0 x="-391.9628" y="-33.951504" xsi:type="point"/>
        <ctrlPoint1 x="-367.08386" y="43.414806" xsi:type="point"/>
    </child>
    <child ID="287" layerID="1" created="1275021078197" x="-519.76587"
        y="-146.2439" width="286.248" height="167.12897"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fd07f00010101f45f2a971dae2c</URIString>
        <point1 x="-519.26587" y="20.385075"/>
        <point2 x="-234.01788" y="-145.7439"/>
        <ID1 xsi:type="node">280</ID1>
        <ID2 xsi:type="node">273</ID2>
        <ctrlPoint0 x="-331.32944" y="13.510656" xsi:type="point"/>
        <ctrlPoint1 x="-359.80524" y="42.060303" xsi:type="point"/>
    </child>
    <child ID="288" layerID="1" created="1275021095092" x="-519.76587"
        y="-146.2439" width="286.57187" height="223.01537"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fd17f00010101f45f2adc9f5833</URIString>
        <point1 x="-519.26587" y="76.27147"/>
        <point2 x="-233.694" y="-145.7439"/>
        <ID1 xsi:type="node">284</ID1>
        <ID2 xsi:type="node">273</ID2>
        <ctrlPoint0 x="-335.31924" y="73.590996" xsi:type="point"/>
        <ctrlPoint1 x="-337.6409" y="15.697149" xsi:type="point"/>
    </child>
    <child ID="289" layerID="1" created="1275021119098" x="-519.76587"
        y="-146.2439" width="287.18793" height="276.21188"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fd27f00010101f45f2ac3f9871c</URIString>
        <point1 x="-519.26587" y="129.468"/>
        <point2 x="-233.07794" y="-145.7439"/>
        <ID1 xsi:type="node">272</ID1>
        <ID2 xsi:type="node">273</ID2>
        <ctrlPoint0 x="-373.29715" y="124.32083" xsi:type="point"/>
        <ctrlPoint1 x="-391.17557" y="120.151245" xsi:type="point"/>
    </child>
    <child ID="290" layerID="1" created="1275021137249" x="-520.45447"
        y="-146.2439" width="288.4474" height="327.0223"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fd37f00010101f45f2a2a8f6d04</URIString>
        <point1 x="-519.95447" y="180.27841"/>
        <point2 x="-232.50708" y="-145.7439"/>
        <ID1 xsi:type="node">283</ID1>
        <ID2 xsi:type="node">273</ID2>
        <ctrlPoint0 x="-393.01328" y="168.23628" xsi:type="point"/>
        <ctrlPoint1 x="-393.86057" y="148.20593" xsi:type="point"/>
    </child>
    <child ID="291" layerID="1" created="1275021177070" x="-520.2256"
        y="-146.2439" width="289.67365" height="382.6562"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd2f7fd37f00010101f45f2a8194ee40</URIString>
        <point1 x="-519.7256" y="235.9123"/>
        <point2 x="-231.05194" y="-145.7439"/>
        <ID1 xsi:type="node">279</ID1>
        <ID2 xsi:type="node">273</ID2>
        <ctrlPoint0 x="-413.20547" y="227.77562" xsi:type="point"/>
        <ctrlPoint1 x="-409.18665" y="266.12463" xsi:type="point"/>
    </child>
    <child ID="294" layerID="1" created="1275021536591" x="-520.3504"
        y="27.584713" width="247.08453" height="211.14911"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd39c1a37f00010101f45f2a4d1bf64a</URIString>
        <point1 x="-519.8504" y="28.084713"/>
        <point2 x="-273.76587" y="238.23383"/>
        <ID1 xsi:type="node">280</ID1>
        <ID2 xsi:type="node">282</ID2>
        <ctrlPoint0 x="-335.22256" y="44.04396" xsi:type="point"/>
        <ctrlPoint1 x="-369.6429" y="238.289" xsi:type="point"/>
    </child>
    <child ID="295" layerID="1" created="1275021568289" x="-519.8507"
        y="188.60994" width="246.58484" height="49.450546"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd39c1a37f00010101f45f2abbc1112e</URIString>
        <point1 x="-519.3507" y="189.10994"/>
        <point2 x="-273.76587" y="237.56049"/>
        <ID1 xsi:type="node">283</ID1>
        <ID2 xsi:type="node">282</ID2>
        <ctrlPoint0 x="-399.82535" y="194.65813" xsi:type="point"/>
        <ctrlPoint1 x="-456.77652" y="236.06541" xsi:type="point"/>
    </child>
    <child ID="296" layerID="1" created="1275021592437" x="-520.2634"
        y="238.47888" width="246.99756" height="12.246292"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd39c1a47f00010101f45f2ae4530bef</URIString>
        <point1 x="-519.7634" y="245.65411"/>
        <point2 x="-273.76587" y="238.97888"/>
        <ID1 xsi:type="node">279</ID1>
        <ID2 xsi:type="node">282</ID2>
        <ctrlPoint0 x="-359.84293" y="258.3567" xsi:type="point"/>
        <ctrlPoint1 x="-450.76828" y="240.7934" xsi:type="point"/>
    </child>
    <child ID="297"
        label="IN: ABS Age By Sex CSV&#xa;OUT: ABS Age By Sex XML"
        layerID="1" created="1275021883554" x="-967.26587"
        y="-117.03487" width="322.5" height="60.531204"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="3" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd3b0f487f00010101f45f2a19e42b5b</URIString>
        <point1 x="-966.76587" y="-57.003662"/>
        <point2 x="-645.26587" y="-88.41652"/>
        <ID1 xsi:type="node">275</ID1>
        <ID2 xsi:type="node">278</ID2>
        <ctrlPoint0 x="-919.2331" y="-134.52216" xsi:type="point"/>
        <ctrlPoint1 x="-745.4051" y="-91.7641" xsi:type="point"/>
    </child>
    <child ID="298" label="IN: ABS Age By Sex XML&#xa;OUT: Dataset XML"
        layerID="1" created="1275021957686" x="-967.26587" y="-81.06636"
        width="323.25598" height="51.54512" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="3" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd3cc2e47f00010101f45f2aca2b26e6</URIString>
        <point1 x="-966.76587" y="-30.02124"/>
        <point2 x="-644.5099" y="-38.05523"/>
        <ID1 xsi:type="node">275</ID1>
        <ID2 xsi:type="node">281</ID2>
        <ctrlPoint0 x="-902.6514" y="-107.12228" xsi:type="point"/>
        <ctrlPoint1 x="-753.892" y="-49.029182" xsi:type="point"/>
    </child>
    <child ID="299"
        label="IN: Dataset XML &amp; ABS MapInfo File&#xa;OUT: Dataset XML With&#xa; Collection District Info"
        layerID="1" created="1275022014346" x="-967.26587" y="-36.70209"
        width="322.88293" height="64.28829" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="3" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd3cc2e57f00010101f45f2a801952a4</URIString>
        <point1 x="-966.76587" y="-14.738159"/>
        <point2 x="-644.88293" y="27.086203"/>
        <ID1 xsi:type="node">275</ID1>
        <ID2 xsi:type="node">280</ID2>
        <ctrlPoint0 x="-903.7828" y="-75.199554" xsi:type="point"/>
        <ctrlPoint1 x="-675.1482" y="29.211294" xsi:type="point"/>
    </child>
    <child ID="300"
        label="IN: ABS Dataset From CSV&#xa;OUT: Updated ABS Dataset XML"
        layerID="1" created="1275022068191" x="-967.26587" y="11.144563"
        width="322.5" height="65.74111" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="3" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd45f6a67f00010101f45f2aadd26fc9</URIString>
        <point1 x="-966.76587" y="16.238281"/>
        <point2 x="-645.26587" y="76.38567"/>
        <ID1 xsi:type="node">275</ID1>
        <ID2 xsi:type="node">284</ID2>
        <ctrlPoint0 x="-913.5621" y="-8.675671" xsi:type="point"/>
        <ctrlPoint1 x="-693.31976" y="75.772545" xsi:type="point"/>
    </child>
    <child ID="301"
        label="IN: KML File From ABS MapInfo&#xa;OUT: Base KML File"
        layerID="1" created="1275022314336" x="-967.26587" y="51.378166"
        width="322.86658" height="76.495674" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="3" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd45f6a77f00010101f45f2a46b2f69f</URIString>
        <point1 x="-966.76587" y="51.878166"/>
        <point2 x="-644.8993" y="127.37384"/>
        <ID1 xsi:type="node">275</ID1>
        <ID2 xsi:type="node">272</ID2>
        <ctrlPoint0 x="-841.6932" y="64.06506" xsi:type="point"/>
        <ctrlPoint1 x="-714.1188" y="122.60436" xsi:type="point"/>
    </child>
    <child ID="302"
        label="IN: Base KML File &amp; Age By Sex XML&#xa;Out: Age By Sex Overlay"
        layerID="1" created="1275022360852" x="-967.26587" y="67.18393"
        width="322.5" height="120.404144" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="3" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd45f6a77f00010101f45f2afeb896ca</URIString>
        <point1 x="-966.76587" y="67.68393"/>
        <point2 x="-645.26587" y="187.08807"/>
        <ID1 xsi:type="node">275</ID1>
        <ID2 xsi:type="node">283</ID2>
        <ctrlPoint0 x="-848.49567" y="108.88029" xsi:type="point"/>
        <ctrlPoint1 x="-809.3727" y="189.4287" xsi:type="point"/>
    </child>
    <child ID="303"
        label="IN: Overlay&#xa;OUT: Overlay with Dublin Core Metadata"
        layerID="1" created="1275022511955" x="-967.26587" y="114.28357"
        width="322.89447" height="122.45218" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="3" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd45f6a87f00010101f45f2a387c392e</URIString>
        <point1 x="-966.76587" y="114.78357"/>
        <point2 x="-644.8714" y="236.23575"/>
        <ID1 xsi:type="node">275</ID1>
        <ID2 xsi:type="node">279</ID2>
        <ctrlPoint0 x="-855.24567" y="237.00275" xsi:type="point"/>
        <ctrlPoint1 x="-768.42316" y="227.44626" xsi:type="point"/>
    </child>
    <child ID="304" label="Apache Commons Lang" layerID="1"
        created="1275022943508" x="-261.26587" y="177.85608"
        width="157.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#CA7777</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd4bd1077f00010101f45f2a1bcfaaa4</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="306" layerID="1" created="1275023055496" x="-520.42426"
        y="136.9508" width="259.762" height="54.918457"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="1" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd4e373b7f00010101f45f2aed0311e5</URIString>
        <point1 x="-519.92426" y="137.4508"/>
        <point2 x="-261.16226" y="191.36926"/>
        <ID1 xsi:type="node">272</ID1>
        <ID2 xsi:type="node">304</ID2>
        <ctrlPoint0 x="-440.2252" y="144.81615" xsi:type="point"/>
        <ctrlPoint1 x="-317.283" y="192.81041" xsi:type="point"/>
    </child>
    <child ID="307" label="SimpleCommandLineParser" layerID="1"
        created="1275023171785" x="-1119.7659" y="270.85614"
        width="180.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#CA7777</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dd4e373b7f00010101f45f2aab6c4c3e</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <layer ID="1" label="Layer 1" created="1263340196981" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <metadata-list category-list-size="0" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/250deadb7f00010100262adc670cbd28</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-1234.2659" y="-356.64386"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" created="1263340196975"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="0" open="true">
            <strokeColor>#B3993333</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="0" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/250deadc7f00010100262adc71a75497</URIString>
            <masterSlide ID="39" created="1263342054108" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <metadata-list category-list-size="0"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/250deb117f00010100262adc53613ec7</URIString>
                <titleStyle ID="40" label="Header"
                    created="1263342054151" x="329.0" y="174.5"
                    width="142.0" height="51.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/250deb127f00010100262adc7d391092</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="41" label="Slide Text"
                    created="1263342054152" x="340.0" y="282.5"
                    width="120.0" height="35.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/250deb127f00010100262adc55ee6d37</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="42" label="Links" created="1263342054153"
                    x="372.5" y="385.0" width="55.0" height="30.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/250deb137f00010100262adc1fa12f61</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2010-01-13</date>
    <mapFilterModel/>
    <modelVersion>5</modelVersion>
    <saveLocation>/home/techxplorer/aus-e-stage/abs-data-fix/diagrams</saveLocation>
    <saveFile>/home/techxplorer/aus-e-stage/abs-data-fix/diagrams/component-overview.vue</saveFile>
</LW-MAP>
