Ensure that the following libraries are available in this directory:

- Apache Commons - Codec (1.4 or above) http://commons.apache.org/codec/
- Apache Commons - Email (1.2 or above) http://commons.apache.org/email/
- Java Mail Library (1.4.3 or above) http://www.oracle.com/technetwork/java/index-jsp-139225.html
