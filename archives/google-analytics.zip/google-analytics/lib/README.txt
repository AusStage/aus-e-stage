This directory needs to contain the libraries as outlined on this web page:

http://code.google.com/apis/gdata/articles/java_client_lib.html

Specifically:

- mail.jar from the JavaMail API
http://java.sun.com/products/javamail/downloads/index.html

- activation.jar from the JavaBeans Activation Framework
http://java.sun.com/products/javabeans/jaf/downloads/index.html

- servlet.jar from the Apache Tomcat library
Should already be installed as part of the existing Java install

- All of the Google Data Java Client Library JARs
(extract from the samples archive)
http://code.google.com/p/gdata-java-client/downloads/list
